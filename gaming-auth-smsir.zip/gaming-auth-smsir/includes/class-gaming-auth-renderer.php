<?php

if (! defined('ABSPATH')) {
    exit;
}

final class Gaming_Auth_Renderer
{
    public static function init(): void
    {
        add_shortcode('gaming_auth', [self::class, 'shortcode']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
        add_action('login_init', [self::class, 'render_login_replacement']);
        add_action('template_redirect', [self::class, 'render_query_replacement']);
    }

    public static function enqueue_assets(bool $force = false): void
    {
        if (! $force && ! self::is_auth_request()) {
            return;
        }

        wp_enqueue_style('gas-auth', GAS_PLUGIN_URL . 'assets/css/auth.css', [], GAS_VERSION);
        wp_enqueue_script('gas-auth', GAS_PLUGIN_URL . 'assets/js/auth.js', ['jquery'], GAS_VERSION, true);

        wp_localize_script('gas-auth', 'gasAuth', [
            'ajaxUrl'    => admin_url('admin-ajax.php'),
            'nonce'      => wp_create_nonce('gas_nonce'),
            'redirectTo' => isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : home_url('/'),
        ]);
    }

    public static function render_login_replacement(): void
    {
        if (! self::is_auth_request() || ! self::can_replace_wp_login()) {
            return;
        }

        status_header(200);
        nocache_headers();
        self::enqueue_assets();

        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">';
        wp_head();
        echo '</head><body class="gas-body">';
        echo self::form_markup();
        wp_footer();
        echo '</body></html>';
        exit;
    }

    public static function render_query_replacement(): void
    {
        if (is_admin() || ! isset($_GET['gaming-auth'])) {
            return;
        }

        status_header(200);
        nocache_headers();
        self::enqueue_assets();

        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">';
        wp_head();
        echo '</head><body class="gas-body">';
        echo self::form_markup();
        wp_footer();
        echo '</body></html>';
        exit;
    }

    public static function shortcode(): string
    {
        self::enqueue_assets(true);

        ob_start();
        ?>
        <div class="gas-shortcode-wrap">
            <button type="button" class="gas-open-auth" id="gas-open-auth">ورود و ثبت نام</button>

            <div class="gas-modal" id="gas-modal" hidden>
                <div class="gas-modal__overlay" data-gas-close="1"></div>
                <div class="gas-modal__dialog" role="dialog" aria-modal="true" aria-label="فرم ورود و ثبت نام">
                    <button type="button" class="gas-modal__close" data-gas-close="1" aria-label="بستن">×</button>
                    <?php echo self::form_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                </div>
            </div>
        </div>
        <?php

        return (string) ob_get_clean();
    }


    private static function can_replace_wp_login(): bool
    {
        if (! (isset($GLOBALS['pagenow']) && 'wp-login.php' === $GLOBALS['pagenow'])) {
            return true;
        }

        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';

        return in_array($action, ['', 'login'], true);
    }

    private static function is_auth_request(): bool
    {
        return (bool) (isset($_GET['gaming-auth']) || (isset($GLOBALS['pagenow']) && 'wp-login.php' === $GLOBALS['pagenow']));
    }

    private static function form_markup(): string
    {
        ob_start();

        ?>
        <div class="gas-shell">
            <div class="gas-card">
                <h1>ورود/ثبت نام</h1>

                <div class="gas-step is-active" data-step="mobile">
                    <label for="gas-mobile">شماره موبایل</label>
                    <input id="gas-mobile" type="tel" placeholder="09xxxxxxxxx" maxlength="11" />
                    <button id="gas-send-otp" type="button">ارسال کد تایید</button>
                </div>

                <div class="gas-step" data-step="otp">
                    <div class="gas-step-toolbar">
                        <button type="button" class="gas-change-mobile">تغییر شماره</button>
                        <span id="gas-confirm-mobile-otp" class="gas-mobile-chip"></span>
                    </div>
                    <label for="gas-otp">کد تایید</label>
                    <input id="gas-otp" type="text" inputmode="numeric" maxlength="8" />
                    <div class="gas-button-row">
                        <button id="gas-resend-otp" type="button" class="gas-btn-secondary">دریافت کد</button>
                        <button id="gas-verify-otp" type="button">تایید کد</button>
                    </div>
                </div>

                <div class="gas-step" data-step="signup">
                    <div class="gas-step-toolbar">
                        <button type="button" class="gas-change-mobile">تغییر شماره</button>
                        <span id="gas-confirm-mobile-signup" class="gas-mobile-chip"></span>
                    </div>
                    <label for="gas-username">انتخاب نام کاربری</label>
                    <input id="gas-username" type="text" autocomplete="off" maxlength="20" />
                    <div id="gas-username-status"></div>
                    <div class="gas-button-row">
                        <button id="gas-back-otp" type="button" class="gas-btn-secondary">بازگشت</button>
                        <button id="gas-complete-signup" type="button" disabled>ثبت نام</button>
                    </div>
                </div>

                <p class="gas-message" id="gas-message"></p>
            </div>
        </div>
        <?php

        return (string) ob_get_clean();
    }
}
