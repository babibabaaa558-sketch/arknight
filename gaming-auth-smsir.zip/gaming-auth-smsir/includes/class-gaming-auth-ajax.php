<?php

if (! defined('ABSPATH')) {
    exit;
}

final class Gaming_Auth_Ajax
{
    public static function init(): void
    {
        add_action('wp_ajax_nopriv_gas_send_otp', [self::class, 'send_otp']);
        add_action('wp_ajax_nopriv_gas_verify_otp', [self::class, 'verify_otp']);
        add_action('wp_ajax_nopriv_gas_check_username', [self::class, 'check_username']);
        add_action('wp_ajax_nopriv_gas_complete_signup', [self::class, 'complete_signup']);
    }

    public static function send_otp(): void
    {
        self::verify_nonce();
        $mobile = self::normalize_mobile($_POST['mobile'] ?? '');

        if (! $mobile) {
            wp_send_json_error(['message' => 'شماره موبایل واردشده معتبر نیست.'], 400);
        }

        $key      = self::otp_key($mobile);
        $stored   = get_transient($key);
        $cooldown = (int) Gaming_Auth_Settings::get('otp_rate_limit');
        $now      = time();

        if (is_array($stored) && ! empty($stored['last_sent']) && ($now - (int) $stored['last_sent']) < $cooldown) {
            $remaining = max(1, $cooldown - ($now - (int) $stored['last_sent']));
            wp_send_json_error(['message' => sprintf('لطفاً %d ثانیه دیگر برای دریافت کد تایید تلاش کنید.', $remaining)], 429);
        }

        $length = (int) Gaming_Auth_Settings::get('otp_length');
        $code   = str_pad((string) wp_rand(0, (10 ** $length) - 1), $length, '0', STR_PAD_LEFT);

        $sent = Gaming_Auth_SMS_Provider::send_verify_code($mobile, $code);
        if (is_wp_error($sent)) {
            wp_send_json_error(['message' => $sent->get_error_message()], 500);
        }

        set_transient($key, [
            'code'      => wp_hash_password($code),
            'last_sent' => $now,
            'verified'  => false,
            'tries'     => 0,
        ], (int) Gaming_Auth_Settings::get('otp_ttl'));

        wp_send_json_success(['message' => 'کد تایید با موفقیت ارسال شد.']);
    }

    public static function verify_otp(): void
    {
        self::verify_nonce();
        $mobile = self::normalize_mobile($_POST['mobile'] ?? '');
        $code   = sanitize_text_field($_POST['code'] ?? '');

        if (! $mobile || ! preg_match('/^[0-9]{4,8}$/', $code)) {
            wp_send_json_error(['message' => 'کد تایید یا شماره موبایل نامعتبر است.'], 400);
        }

        $key = self::otp_key($mobile);
        $otp = get_transient($key);

        if (! is_array($otp) || empty($otp['code'])) {
            wp_send_json_error(['message' => 'کد تایید منقضی شده است. لطفاً دوباره کد بگیرید.'], 410);
        }

        $tries = (int) ($otp['tries'] ?? 0);
        if ($tries >= 5) {
            delete_transient($key);
            wp_send_json_error(['message' => 'تعداد تلاش‌های ناموفق بیش از حد مجاز بود. لطفاً دوباره کد دریافت کنید.'], 429);
        }

        if (! wp_check_password($code, $otp['code'])) {
            $otp['tries'] = $tries + 1;
            set_transient($key, $otp, (int) Gaming_Auth_Settings::get('otp_ttl'));
            wp_send_json_error(['message' => 'کد تایید اشتباه است.'], 401);
        }

        $otp['verified'] = true;
        set_transient($key, $otp, (int) Gaming_Auth_Settings::get('otp_ttl'));

        $user = get_users([
            'meta_key'   => 'billing_phone',
            'meta_value' => $mobile,
            'number'     => 1,
            'fields'     => 'all',
        ]);

        if (! empty($user)) {
            self::login_user($user[0]);
            delete_transient($key);
            wp_send_json_success(['existing_user' => true, 'redirect' => self::redirect_url(), 'message' => 'ورود با موفقیت انجام شد.']);
        }

        wp_send_json_success(['existing_user' => false, 'message' => 'شماره موبایل تایید شد.']);
    }

    public static function check_username(): void
    {
        self::verify_nonce();
        $username = sanitize_user($_POST['username'] ?? '');

        if (strlen($username) < 4) {
            wp_send_json_error(['message' => 'نام کاربری باید حداقل ۴ کاراکتر باشد.'], 400);
        }

        if (strlen($username) > 20) {
            wp_send_json_error(['message' => 'نام کاربری حداکثر باید ۲۰ کاراکتر باشد.'], 400);
        }

        if (username_exists($username)) {
            wp_send_json_error(['message' => 'این نام کاربری قبلاً ثبت شده است.'], 409);
        }

        wp_send_json_success(['message' => 'این نام کاربری قابل استفاده است ✅']);
    }

    public static function complete_signup(): void
    {
        self::verify_nonce();

        $mobile   = self::normalize_mobile($_POST['mobile'] ?? '');
        $username = sanitize_user($_POST['username'] ?? '');

        if (! $mobile || strlen($username) < 4 || strlen($username) > 20) {
            wp_send_json_error(['message' => 'اطلاعات ثبت‌نام کامل یا معتبر نیست.'], 400);
        }

        if (username_exists($username)) {
            wp_send_json_error(['message' => 'این نام کاربری قبلاً ثبت شده است.'], 409);
        }

        $otp = get_transient(self::otp_key($mobile));
        if (! is_array($otp) || empty($otp['verified'])) {
            wp_send_json_error(['message' => 'ابتدا باید شماره موبایل را تایید کنید.'], 403);
        }

        $password = wp_generate_password(20, true, true);
        $email    = $username . '+' . wp_generate_password(8, false, false) . '@example.local';

        $user_id = wp_insert_user([
            'user_login' => $username,
            'user_pass'  => $password,
            'user_email' => $email,
            'role'       => get_option('default_role', 'subscriber'),
        ]);

        if (is_wp_error($user_id)) {
            wp_send_json_error(['message' => $user_id->get_error_message()], 500);
        }

        update_user_meta($user_id, 'billing_phone', $mobile);
        update_user_meta($user_id, 'gas_mobile', $mobile);

        self::login_user(get_user_by('id', $user_id));
        delete_transient(self::otp_key($mobile));

        wp_send_json_success(['redirect' => self::redirect_url(), 'message' => 'ثبت‌نام با موفقیت انجام شد.']);
    }

    private static function verify_nonce(): void
    {
        check_ajax_referer('gas_nonce', 'nonce');
    }

    private static function normalize_mobile(string $mobile): string
    {
        $mobile = preg_replace('/\D+/', '', $mobile);
        if (! is_string($mobile)) {
            return '';
        }

        if (strpos($mobile, '98') === 0 && strlen($mobile) === 12) {
            $mobile = '0' . substr($mobile, 2);
        }

        if (strlen($mobile) !== 11 || strpos($mobile, '09') !== 0) {
            return '';
        }

        return $mobile;
    }

    private static function otp_key(string $mobile): string
    {
        return 'gas_otp_' . md5($mobile);
    }

    private static function login_user(WP_User $user): void
    {
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        do_action('wp_login', $user->user_login, $user);
    }

    private static function redirect_url(): string
    {
        return ! empty($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : home_url('/');
    }
}
