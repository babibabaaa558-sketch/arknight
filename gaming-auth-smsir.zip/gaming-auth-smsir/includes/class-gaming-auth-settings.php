<?php

if (! defined('ABSPATH')) {
    exit;
}

final class Gaming_Auth_Settings
{
    private const OPTION_KEY = 'gas_settings';

    public static function init(): void
    {
        add_action('admin_init', [self::class, 'register_settings']);
        add_action('admin_menu', [self::class, 'register_menu']);
    }

    public static function register_settings(): void
    {
        register_setting('gas_settings_group', self::OPTION_KEY, [
            'type'              => 'array',
            'sanitize_callback' => [self::class, 'sanitize'],
            'default'           => self::defaults(),
        ]);

        add_settings_section('gas_main_section', __('SMS.ir Settings', 'gaming-auth-smsir'), '__return_false', 'gas-settings');

        $fields = [
            'api_key'           => __('API Key', 'gaming-auth-smsir'),
            'template_id'       => __('Template ID', 'gaming-auth-smsir'),
            'code_param_name'   => __('Template Param Name for OTP', 'gaming-auth-smsir'),
            'otp_length'        => __('OTP Length', 'gaming-auth-smsir'),
            'otp_ttl'           => __('OTP Expiration (seconds)', 'gaming-auth-smsir'),
            'otp_rate_limit'    => __('Cooldown Between Sends (seconds)', 'gaming-auth-smsir'),
        ];

        foreach ($fields as $key => $label) {
            add_settings_field($key, $label, [self::class, 'render_field'], 'gas-settings', 'gas_main_section', ['key' => $key]);
        }
    }

    public static function register_menu(): void
    {
        add_menu_page(
            __('Gaming Auth', 'gaming-auth-smsir'),
            __('Gaming Auth', 'gaming-auth-smsir'),
            'manage_options',
            'gas-settings',
            [self::class, 'render_page'],
            'dashicons-shield'
        );
    }

    public static function sanitize(array $input): array
    {
        $defaults = self::defaults();
        $output   = $defaults;

        $output['api_key']         = sanitize_text_field($input['api_key'] ?? '');
        $output['template_id']     = sanitize_text_field($input['template_id'] ?? '');
        $output['code_param_name'] = sanitize_key($input['code_param_name'] ?? 'code');
        $output['otp_length']      = max(4, min(8, absint($input['otp_length'] ?? $defaults['otp_length'])));
        $output['otp_ttl']         = max(60, min(900, absint($input['otp_ttl'] ?? $defaults['otp_ttl'])));
        $output['otp_rate_limit']  = max(15, min(300, absint($input['otp_rate_limit'] ?? $defaults['otp_rate_limit'])));

        return $output;
    }

    public static function defaults(): array
    {
        return [
            'api_key'         => '',
            'template_id'     => '',
            'code_param_name' => 'code',
            'otp_length'      => 5,
            'otp_ttl'         => 120,
            'otp_rate_limit'  => 60,
        ];
    }

    public static function get(string $key)
    {
        $settings = get_option(self::OPTION_KEY, self::defaults());
        $settings = wp_parse_args($settings, self::defaults());

        return $settings[$key] ?? null;
    }

    public static function render_field(array $args): void
    {
        $key   = $args['key'];
        $value = self::get($key);
        $type  = in_array($key, ['otp_length', 'otp_ttl', 'otp_rate_limit'], true) ? 'number' : 'text';
        $attrs = 'class="regular-text"';

        if ('number' === $type) {
            $attrs = 'min="1" step="1"';
        }

        printf(
            '<input type="%1$s" name="%2$s[%3$s]" value="%4$s" %5$s />',
            esc_attr($type),
            esc_attr(self::OPTION_KEY),
            esc_attr($key),
            esc_attr((string) $value),
            $attrs // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        );
    }

    public static function render_page(): void
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        echo '<div class="wrap"><h1>Gaming Auth Settings</h1><form method="post" action="options.php">';
        settings_fields('gas_settings_group');
        do_settings_sections('gas-settings');
        submit_button();
        echo '</form></div>';
    }
}
