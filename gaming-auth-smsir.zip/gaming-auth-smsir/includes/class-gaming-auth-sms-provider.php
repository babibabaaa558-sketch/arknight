<?php

if (! defined('ABSPATH')) {
    exit;
}

final class Gaming_Auth_SMS_Provider
{
    private const ENDPOINT = 'https://api.sms.ir/v1/send/verify';

    public static function send_verify_code(string $mobile, string $code)
    {
        $api_key     = (string) Gaming_Auth_Settings::get('api_key');
        $template_id = (string) Gaming_Auth_Settings::get('template_id');
        $param_name  = (string) Gaming_Auth_Settings::get('code_param_name');

        if (empty($api_key) || empty($template_id)) {
            return new WP_Error('gas_missing_config', __('SMS settings are incomplete.', 'gaming-auth-smsir'));
        }

        $payload = [
            'mobile'     => $mobile,
            'templateId' => $template_id,
            'parameters' => [
                [
                    'name'  => $param_name,
                    'value' => $code,
                ],
            ],
        ];

        $response = wp_remote_post(self::ENDPOINT, [
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'x-api-key'    => $api_key,
            ],
            'body'    => wp_json_encode($payload),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $status = wp_remote_retrieve_response_code($response);
        $body   = json_decode((string) wp_remote_retrieve_body($response), true);

        if ($status < 200 || $status >= 300) {
            $message = $body['message'] ?? __('SMS service failed.', 'gaming-auth-smsir');
            return new WP_Error('gas_sms_failed', (string) $message, ['status' => $status, 'body' => $body]);
        }

        return true;
    }
}
