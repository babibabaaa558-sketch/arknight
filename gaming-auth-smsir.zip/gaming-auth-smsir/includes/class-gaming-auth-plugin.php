<?php

if (! defined('ABSPATH')) {
    exit;
}

require_once GAS_PLUGIN_PATH . 'includes/class-gaming-auth-settings.php';
require_once GAS_PLUGIN_PATH . 'includes/class-gaming-auth-sms-provider.php';
require_once GAS_PLUGIN_PATH . 'includes/class-gaming-auth-ajax.php';
require_once GAS_PLUGIN_PATH . 'includes/class-gaming-auth-renderer.php';

final class Gaming_Auth_Plugin
{
    private static $instance = null;

    public static function instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        add_action('init', [$this, 'init']);
        register_activation_hook(GAS_PLUGIN_FILE, [$this, 'activate']);
    }

    public function activate(): void
    {
        flush_rewrite_rules();
    }

    public function init(): void
    {
        Gaming_Auth_Settings::init();
        Gaming_Auth_Renderer::init();
        Gaming_Auth_Ajax::init();

        add_filter('login_url', [$this, 'filter_login_url'], 10, 3);
        add_filter('register_url', [$this, 'filter_register_url']);
    }

    public function filter_login_url(string $login_url, string $redirect, bool $force_reauth): string
    {
        $url = home_url('/?gaming-auth=1');

        if (! empty($redirect)) {
            $url = add_query_arg('redirect_to', rawurlencode($redirect), $url);
        }

        if ($force_reauth) {
            $url = add_query_arg('reauth', '1', $url);
        }

        return $url;
    }

    public function filter_register_url(string $register_url): string
    {
        return home_url('/?gaming-auth=1');
    }
}
