<?php
/**
 * Plugin Name: Gaming Auth SMS.ir
 * Description: Professional OTP-based login & registration with SMS.ir and gaming style UI.
 * Version: 1.0.7
 * Author: Codex Agent
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: gaming-auth-smsir
 */

if (! defined('ABSPATH')) {
    exit;
}

define('GAS_PLUGIN_FILE', __FILE__);
define('GAS_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('GAS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('GAS_VERSION', '1.0.7');

require_once GAS_PLUGIN_PATH . 'includes/class-gaming-auth-plugin.php';

Gaming_Auth_Plugin::instance();
