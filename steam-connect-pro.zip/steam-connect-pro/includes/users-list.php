<?php
if (!defined('ABSPATH')) exit;

function scp_connected_users_shortcode() {
    global $wpdb;

    $meta_keys = array('steam_id', 'gas_mobile');
    $placeholders = implode(', ', array_fill(0, count($meta_keys), '%s'));

    $users = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT user_id,
                    MAX(CASE WHEN meta_key = 'steam_id' THEN meta_value END) AS steam_id,
                    MAX(CASE WHEN meta_key = 'gas_mobile' THEN meta_value END) AS gas_mobile
             FROM {$wpdb->usermeta}
             WHERE meta_key IN ($placeholders)
             GROUP BY user_id
             ORDER BY user_id DESC",
            ...$meta_keys
        )
    );

    if ( ! $users ) {
        return '<p>' . esc_html__( 'No users found yet.', 'steam-connect-pro' ) . '</p>';
    }

    ob_start();
    ?>
    <div class="scp-users-grid">
        <?php foreach ( $users as $user ) :
            $wp_user = get_user_by( 'id', (int) $user->user_id );
            if ( ! $wp_user ) {
                continue;
            }

            $steam_data = null;
            $has_steam  = ! empty( $user->steam_id );

            if ( $has_steam ) {
                $steam_id   = sanitize_text_field( $user->steam_id );
                $steam_data = scp_get_steam_user_info( $steam_id );
                if ( ! $steam_data ) {
                    $has_steam = false;
                }
            }

            $wp_name = trim( (string) $wp_user->display_name );
            $display_name = $wp_name !== ''
                ? $wp_name
                : ( $has_steam ? $steam_data['name'] : $wp_user->user_login );

            $avatar_url = scp_get_user_avatar_url( $wp_user->ID, 124 );

            $steam_level = $has_steam ? intval( $steam_data['level'] ) : 0;
            $level_class = 'scp-level-basic';

            if ( $steam_level >= 11 && $steam_level <= 30 ) {
                $level_class = 'scp-level-bronze';
            } elseif ( $steam_level >= 31 && $steam_level <= 60 ) {
                $level_class = 'scp-level-silver';
            } elseif ( $steam_level >= 61 && $steam_level <= 100 ) {
                $level_class = 'scp-level-gold';
            } elseif ( $steam_level >= 101 ) {
                $level_class = 'scp-level-platinum';
            }
            ?>
            <article class="scp-user-card" <?php echo $has_steam ? 'data-steamid="' . esc_attr( $steam_data['steamid'] ) . '"' : ''; ?>>
                <?php if ( is_user_logged_in() && get_current_user_id() !== (int) $user->user_id ) : ?>
                    <button type="button" class="scp-chat-launch" data-target-user="<?php echo esc_attr( (int) $user->user_id ); ?>" data-target-name="<?php echo esc_attr( $display_name ); ?>">
                        💬Chat
                    </button>
                <?php endif; ?>

                <div class="scp-card-head">
                    <div class="scp-avatar-presence-wrap" data-scp-site-user-id="<?php echo esc_attr( (int) $user->user_id ); ?>">
                        <img src="<?php echo esc_url( $avatar_url ); ?>" class="scp-avatar" alt="<?php echo esc_attr( $display_name ); ?>">
                        <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                    </div>

                    <div class="scp-user-info">
                        <h3 class="scp-name"><?php echo esc_html( $display_name ); ?><?php echo scp_get_verified_badge_html((int) $wp_user->ID, ['class' => 'scp-verified-badge-inline']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></h3>

                        <?php if ( $has_steam ) : ?>
                            <div class="scp-meta-row">
                                <span class="scp-level-badge <?php echo esc_attr( $level_class ); ?>" data-tooltip="<?php esc_attr_e( 'Steam Level', 'steam-connect-pro' ); ?>">
                                    <?php printf( esc_html__( 'Lv. %d', 'steam-connect-pro' ), $steam_level ); ?>
                                </span>

                                <span class="scp-online-status <?php echo ( $steam_data['online'] > 0 ? 'online' : 'offline' ); ?>" data-tooltip="in steam">
                                    <?php echo ( $steam_data['online'] > 0 ? esc_html__( 'Online', 'steam-connect-pro' ) : esc_html__( 'Offline', 'steam-connect-pro' ) ); ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="scp-card-actions">
                    <?php if ( $has_steam ) : ?>
                        <a href="<?php echo esc_url( $steam_data['profile_url'] ); ?>" target="_blank" rel="noopener noreferrer" class="scp-profile-link">
                            <?php esc_html_e( 'Steam Profile', 'steam-connect-pro' ); ?>
                        </a>
                    <?php endif; ?>
                    <?php $public_profile_url = add_query_arg( 'scp_site_user', (int) $wp_user->ID, home_url( '/' ) ); ?>
                    <a href="<?php echo esc_url( $public_profile_url ); ?>" class="scp-profile-link scp-profile-link-alt">
                        <?php esc_html_e( 'پروفایل کاربر', 'steam-connect-pro' ); ?>
                    </a>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
    <?php

    return ob_get_clean();
}
add_shortcode( 'steam_connected_users', 'scp_connected_users_shortcode' );
