<?php
if (!defined('ABSPATH')) exit;

/**
 * AJAX: Check online status for a list of Steam IDs.
 * Expects POST: steamids (comma separated) and nonce.
 */
add_action( 'wp_ajax_scp_check_online_status', 'scp_check_online_status' );
add_action( 'wp_ajax_nopriv_scp_check_online_status', 'scp_check_online_status' );

function scp_check_online_status() {
    if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'scp-ajax' ) ) {
        wp_send_json_error( [ 'message' => 'invalid_nonce' ], 400 );
    }

    if ( empty( $_POST['steamids'] ) ) {
        wp_send_json_error( [ 'message' => 'no_steamids' ], 400 );
    }

    $raw = sanitize_text_field( wp_unslash( $_POST['steamids'] ) );
    $steamids = array_filter( array_map( 'trim', explode( ',', $raw ) ) );

    $steamids = array_filter( $steamids, function ( $id ) {
        return preg_match( '/^\d+$/', $id );
    } );

    if ( empty( $steamids ) ) {
        wp_send_json_error( [ 'message' => 'invalid_steamids' ], 400 );
    }

    $api_key = scp_get_api_key();
    if ( empty( $api_key ) ) {
        wp_send_json_error( [ 'message' => 'missing_api_key' ], 500 );
    }

    $result = [];
    $to_query = [];

    foreach ( $steamids as $sid ) {
        $cache_key = 'scp_presence_' . $sid;
        $cached = get_transient( $cache_key );
        if ( $cached !== false && is_array( $cached ) ) {
            $result[ $sid ] = $cached;
        } else {
            $to_query[] = $sid;
        }
    }

    if ( ! empty( $to_query ) ) {
        $query_ids = implode( ',', array_map( 'sanitize_text_field', $to_query ) );

        $url = add_query_arg( [
            'key'      => $api_key,
            'steamids' => $query_ids,
        ], 'https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/' );

        $response = wp_remote_get( $url, [ 'timeout' => 10 ] );
        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => 'remote_error' ], 502 );
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( ! empty( $data['response']['players'] ) && is_array( $data['response']['players'] ) ) {
            foreach ( $data['response']['players'] as $player ) {
                $sid = isset( $player['steamid'] ) ? $player['steamid'] : '';
                if ( ! $sid ) {
                    continue;
                }

                $current_game_id = isset( $player['gameid'] ) ? sanitize_text_field( $player['gameid'] ) : '';
                $current_game_name = isset( $player['gameextrainfo'] ) ? sanitize_text_field( $player['gameextrainfo'] ) : '';

                $presence = [
                    'status'             => ( isset( $player['personastate'] ) && intval( $player['personastate'] ) > 0 ) ? 'Online' : 'Offline',
                    'current_game_name'  => $current_game_name,
                    'current_game_image' => $current_game_id ? 'https://cdn.cloudflare.steamstatic.com/steam/apps/' . $current_game_id . '/header.jpg' : '',
                ];

                $result[ $sid ] = $presence;
                set_transient( 'scp_presence_' . $sid, $presence, 20 );
            }
        }
    }

    wp_send_json_success( $result );
}

/**
 * AJAX: mark current logged-in user as online on this site.
 */
add_action( 'wp_ajax_scp_ping_site_presence', 'scp_ping_site_presence' );
function scp_ping_site_presence() {
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => 'unauthorized' ], 401 );
    }

    if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'scp-ajax' ) ) {
        wp_send_json_error( [ 'message' => 'invalid_nonce' ], 400 );
    }

    $user_id = get_current_user_id();
    update_user_meta( $user_id, 'scp_last_seen', time() );

    wp_send_json_success( [ 'user_id' => $user_id ] );
}

/**
 * AJAX: get website online/offline status for user IDs.
 * Expects POST: user_ids (comma separated) and nonce.
 */
add_action( 'wp_ajax_scp_get_site_presence', 'scp_get_site_presence' );
add_action( 'wp_ajax_nopriv_scp_get_site_presence', 'scp_get_site_presence' );
function scp_get_site_presence() {
    if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'scp-ajax' ) ) {
        wp_send_json_error( [ 'message' => 'invalid_nonce' ], 400 );
    }

    if ( empty( $_POST['user_ids'] ) ) {
        wp_send_json_error( [ 'message' => 'no_user_ids' ], 400 );
    }

    $raw = sanitize_text_field( wp_unslash( $_POST['user_ids'] ) );
    $user_ids = array_filter( array_map( 'intval', explode( ',', $raw ) ) );

    if ( empty( $user_ids ) ) {
        wp_send_json_error( [ 'message' => 'invalid_user_ids' ], 400 );
    }

    $online_window = 70;
    $now = time();
    $result = [];

    foreach ( $user_ids as $user_id ) {
        $user_id = (int) $user_id;
        if ( $user_id <= 0 ) {
            continue;
        }

        $last_seen = (int) get_user_meta( $user_id, 'scp_last_seen', true );
        $is_online = $last_seen > 0 && ( $now - $last_seen ) <= $online_window;

        $result[ (string) $user_id ] = [
            'online' => $is_online,
            'last_seen' => $last_seen,
        ];
    }

    wp_send_json_success( $result );
}
